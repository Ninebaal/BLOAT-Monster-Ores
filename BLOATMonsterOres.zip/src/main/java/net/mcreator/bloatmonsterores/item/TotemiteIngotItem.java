
package net.mcreator.bloatmonsterores.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class TotemiteIngotItem extends Item {
	public TotemiteIngotItem() {
		super(new Item.Properties().stacksTo(64).fireResistant().rarity(Rarity.RARE));
	}
}

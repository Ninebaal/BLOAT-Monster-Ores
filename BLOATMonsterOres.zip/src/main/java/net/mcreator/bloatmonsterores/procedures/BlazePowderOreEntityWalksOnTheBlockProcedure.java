package net.mcreator.bloatmonsterores.procedures;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class BlazePowderOreEntityWalksOnTheBlockProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		BlockState activeblaze = Blocks.AIR.defaultBlockState();
		world.setBlock(BlockPos.containing(x + 0, y + 1, z + 0), Blocks.FIRE.defaultBlockState(), 3);
	}
}


/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bloatmonsterores.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;

import net.mcreator.bloatmonsterores.item.XpeteriteItem;
import net.mcreator.bloatmonsterores.item.UnrefinedTotemiteItem;
import net.mcreator.bloatmonsterores.item.TotemiteIngotItem;
import net.mcreator.bloatmonsterores.item.FreshFleshItem;
import net.mcreator.bloatmonsterores.item.EndysterPickaxeItem;
import net.mcreator.bloatmonsterores.item.EndysterIngotItem;
import net.mcreator.bloatmonsterores.item.ChargedGunPowderItem;
import net.mcreator.bloatmonsterores.item.ChargedExplosivePickaxeItem;
import net.mcreator.bloatmonsterores.BloatMonsterOresMod;

public class BloatMonsterOresModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, BloatMonsterOresMod.MODID);
	public static final RegistryObject<Item> BLAZE_POWDER_ORE = block(BloatMonsterOresModBlocks.BLAZE_POWDER_ORE);
	public static final RegistryObject<Item> ENDER_PEARL_ORE = block(BloatMonsterOresModBlocks.ENDER_PEARL_ORE);
	public static final RegistryObject<Item> SLIME_BALL_ORE = block(BloatMonsterOresModBlocks.SLIME_BALL_ORE);
	public static final RegistryObject<Item> GHAST_TEAR_ORE = block(BloatMonsterOresModBlocks.GHAST_TEAR_ORE);
	public static final RegistryObject<Item> FOSSIL_ORE = block(BloatMonsterOresModBlocks.FOSSIL_ORE);
	public static final RegistryObject<Item> ROTTEN_FLESH_ORE = block(BloatMonsterOresModBlocks.ROTTEN_FLESH_ORE);
	public static final RegistryObject<Item> PHANTOM_MEMBRANE_ORE = block(BloatMonsterOresModBlocks.PHANTOM_MEMBRANE_ORE);
	public static final RegistryObject<Item> GLOW_INK_ORE = block(BloatMonsterOresModBlocks.GLOW_INK_ORE);
	public static final RegistryObject<Item> GUNPOWDER_ORE = block(BloatMonsterOresModBlocks.GUNPOWDER_ORE);
	public static final RegistryObject<Item> SHULKER_SHELL_ORE = block(BloatMonsterOresModBlocks.SHULKER_SHELL_ORE);
	public static final RegistryObject<Item> UNREFINED_TOTEMITE = REGISTRY.register("unrefined_totemite", () -> new UnrefinedTotemiteItem());
	public static final RegistryObject<Item> TOTEMITE_INGOT = REGISTRY.register("totemite_ingot", () -> new TotemiteIngotItem());
	public static final RegistryObject<Item> TOTEMITE_ORE = block(BloatMonsterOresModBlocks.TOTEMITE_ORE);
	public static final RegistryObject<Item> XPETERITE_ORE = block(BloatMonsterOresModBlocks.XPETERITE_ORE);
	public static final RegistryObject<Item> XPETERITE = REGISTRY.register("xpeterite", () -> new XpeteriteItem());
	public static final RegistryObject<Item> BLAZE_POWDER_BLOCK = block(BloatMonsterOresModBlocks.BLAZE_POWDER_BLOCK);
	public static final RegistryObject<Item> ENDER_PEARL_BLOCK = block(BloatMonsterOresModBlocks.ENDER_PEARL_BLOCK);
	public static final RegistryObject<Item> GHASTLY_RESIN_BLOCK = block(BloatMonsterOresModBlocks.GHASTLY_RESIN_BLOCK);
	public static final RegistryObject<Item> GLOW_GLAND_BLOCK = block(BloatMonsterOresModBlocks.GLOW_GLAND_BLOCK);
	public static final RegistryObject<Item> GUNPOWDER_BLOCK = block(BloatMonsterOresModBlocks.GUNPOWDER_BLOCK);
	public static final RegistryObject<Item> PHANTOM_CYTOPLASM = block(BloatMonsterOresModBlocks.PHANTOM_CYTOPLASM);
	public static final RegistryObject<Item> SPIDER_EYE_ORE = block(BloatMonsterOresModBlocks.SPIDER_EYE_ORE);
	public static final RegistryObject<Item> ECHO_SHARD_ORE = block(BloatMonsterOresModBlocks.ECHO_SHARD_ORE);
	public static final RegistryObject<Item> ENDYSTER_BRICKS = block(BloatMonsterOresModBlocks.ENDYSTER_BRICKS);
	public static final RegistryObject<Item> TOTEMITE_BRICKS = block(BloatMonsterOresModBlocks.TOTEMITE_BRICKS);
	public static final RegistryObject<Item> ENDYSTER_INGOT = REGISTRY.register("endyster_ingot", () -> new EndysterIngotItem());
	public static final RegistryObject<Item> CHARGED_GUN_POWDER = REGISTRY.register("charged_gun_powder", () -> new ChargedGunPowderItem());
	public static final RegistryObject<Item> CHISELED_ENDYSTER_BRICKS = block(BloatMonsterOresModBlocks.CHISELED_ENDYSTER_BRICKS);
	public static final RegistryObject<Item> CHISELED_TOTEMITE_BRICKS = block(BloatMonsterOresModBlocks.CHISELED_TOTEMITE_BRICKS);
	public static final RegistryObject<Item> ENDYSTER_BRICK_SLAB = block(BloatMonsterOresModBlocks.ENDYSTER_BRICK_SLAB);
	public static final RegistryObject<Item> TOTEMITE_BRICK_SLAB = block(BloatMonsterOresModBlocks.TOTEMITE_BRICK_SLAB);
	public static final RegistryObject<Item> PETRIFIED_WOOD_WOOD = block(BloatMonsterOresModBlocks.PETRIFIED_WOOD_WOOD);
	public static final RegistryObject<Item> PETRIFIED_WOOD_LOG = block(BloatMonsterOresModBlocks.PETRIFIED_WOOD_LOG);
	public static final RegistryObject<Item> PETRIFIED_WOOD_PLANKS = block(BloatMonsterOresModBlocks.PETRIFIED_WOOD_PLANKS);
	public static final RegistryObject<Item> PETRIFIED_WOOD_LEAVES = block(BloatMonsterOresModBlocks.PETRIFIED_WOOD_LEAVES);
	public static final RegistryObject<Item> PETRIFIED_WOOD_STAIRS = block(BloatMonsterOresModBlocks.PETRIFIED_WOOD_STAIRS);
	public static final RegistryObject<Item> PETRIFIED_WOOD_SLAB = block(BloatMonsterOresModBlocks.PETRIFIED_WOOD_SLAB);
	public static final RegistryObject<Item> PETRIFIED_WOOD_FENCE = block(BloatMonsterOresModBlocks.PETRIFIED_WOOD_FENCE);
	public static final RegistryObject<Item> PETRIFIED_WOOD_FENCE_GATE = block(BloatMonsterOresModBlocks.PETRIFIED_WOOD_FENCE_GATE);
	public static final RegistryObject<Item> PETRIFIED_WOOD_PRESSURE_PLATE = block(BloatMonsterOresModBlocks.PETRIFIED_WOOD_PRESSURE_PLATE);
	public static final RegistryObject<Item> PETRIFIED_WOOD_BUTTON = block(BloatMonsterOresModBlocks.PETRIFIED_WOOD_BUTTON);
	public static final RegistryObject<Item> PETRIFIED_WOOD_DOOR = doubleBlock(BloatMonsterOresModBlocks.PETRIFIED_WOOD_DOOR);
	public static final RegistryObject<Item> OREWOOD_COAL = block(BloatMonsterOresModBlocks.OREWOOD_COAL);
	public static final RegistryObject<Item> OREWOOD_IRON = block(BloatMonsterOresModBlocks.OREWOOD_IRON);
	public static final RegistryObject<Item> OREWOOD_GOLD = block(BloatMonsterOresModBlocks.OREWOOD_GOLD);
	public static final RegistryObject<Item> OREWOOD_REDSTONE = block(BloatMonsterOresModBlocks.OREWOOD_REDSTONE);
	public static final RegistryObject<Item> OREWOOD_EMERALD = block(BloatMonsterOresModBlocks.OREWOOD_EMERALD);
	public static final RegistryObject<Item> OREWOOD_LAPIS = block(BloatMonsterOresModBlocks.OREWOOD_LAPIS);
	public static final RegistryObject<Item> DEEPSLATE_BLAZE_POWDER_ORE = block(BloatMonsterOresModBlocks.DEEPSLATE_BLAZE_POWDER_ORE);
	public static final RegistryObject<Item> DEEPSLATE_ENDER_PEARL_ORE = block(BloatMonsterOresModBlocks.DEEPSLATE_ENDER_PEARL_ORE);
	public static final RegistryObject<Item> DEEPSLATE_MAGMA_CREAM_ORE = block(BloatMonsterOresModBlocks.DEEPSLATE_MAGMA_CREAM_ORE);
	public static final RegistryObject<Item> DEEPSLATE_GHAST_TEAR_ORE = block(BloatMonsterOresModBlocks.DEEPSLATE_GHAST_TEAR_ORE);
	public static final RegistryObject<Item> FRESH_FLESH = REGISTRY.register("fresh_flesh", () -> new FreshFleshItem());
	public static final RegistryObject<Item> CHARGED_EXPLOSIVE_PICKAXE = REGISTRY.register("charged_explosive_pickaxe", () -> new ChargedExplosivePickaxeItem());
	public static final RegistryObject<Item> ENDYSTER_PICKAXE = REGISTRY.register("endyster_pickaxe", () -> new EndysterPickaxeItem());
	public static final RegistryObject<Item> DEEPSLATE_FRESH_FLESH_ORE = block(BloatMonsterOresModBlocks.DEEPSLATE_FRESH_FLESH_ORE);
	public static final RegistryObject<Item> DEEPSLATE_PHANTOM_MEMBRANE_ORE = block(BloatMonsterOresModBlocks.DEEPSLATE_PHANTOM_MEMBRANE_ORE);
	public static final RegistryObject<Item> DEEPSLATE_GLOW_INK_ORE = block(BloatMonsterOresModBlocks.DEEPSLATE_GLOW_INK_ORE);
	public static final RegistryObject<Item> DEEPSLATE_GUNPOWDER_ORE = block(BloatMonsterOresModBlocks.DEEPSLATE_GUNPOWDER_ORE);
	public static final RegistryObject<Item> DEEPSLATE_SHULKER_SHELL_ORE = block(BloatMonsterOresModBlocks.DEEPSLATE_SHULKER_SHELL_ORE);
	public static final RegistryObject<Item> DEEPSLATE_TOTEMITE_ORE = block(BloatMonsterOresModBlocks.DEEPSLATE_TOTEMITE_ORE);
	public static final RegistryObject<Item> DEEPSLATE_XPETERITE_ORE = block(BloatMonsterOresModBlocks.DEEPSLATE_XPETERITE_ORE);
	public static final RegistryObject<Item> DEEPSLATE_SPIDER_EYE_ORE = block(BloatMonsterOresModBlocks.DEEPSLATE_SPIDER_EYE_ORE);
	public static final RegistryObject<Item> PETRIFIED_WOOD_TRAP_DOOR = block(BloatMonsterOresModBlocks.PETRIFIED_WOOD_TRAP_DOOR);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), new Item.Properties()));
	}
}

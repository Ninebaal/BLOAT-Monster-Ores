
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bloatmonsterores.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.bloatmonsterores.BloatMonsterOresMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class BloatMonsterOresModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BloatMonsterOresMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {

			tabData.accept(BloatMonsterOresModBlocks.BLAZE_POWDER_BLOCK.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.ENDER_PEARL_BLOCK.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.GHASTLY_RESIN_BLOCK.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.GLOW_GLAND_BLOCK.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.GUNPOWDER_BLOCK.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PHANTOM_CYTOPLASM.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.ENDYSTER_BRICKS.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.TOTEMITE_BRICKS.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.CHISELED_ENDYSTER_BRICKS.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.CHISELED_TOTEMITE_BRICKS.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.ENDYSTER_BRICK_SLAB.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.TOTEMITE_BRICK_SLAB.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PETRIFIED_WOOD_WOOD.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PETRIFIED_WOOD_LOG.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PETRIFIED_WOOD_PLANKS.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PETRIFIED_WOOD_STAIRS.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PETRIFIED_WOOD_SLAB.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PETRIFIED_WOOD_FENCE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PETRIFIED_WOOD_FENCE_GATE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PETRIFIED_WOOD_PRESSURE_PLATE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PETRIFIED_WOOD_BUTTON.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PETRIFIED_WOOD_DOOR.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PETRIFIED_WOOD_TRAP_DOOR.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.ENDYSTER_BRICK_STAIRS.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.TOTEMITE_BRICK_STAIRS.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.ENDYSTER_BRICK_WALLS.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.TOTEMITE_BRICK_WALLS.get().asItem());

		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {

			tabData.accept(BloatMonsterOresModItems.UNREFINED_TOTEMITE.get());
			tabData.accept(BloatMonsterOresModItems.TOTEMITE_INGOT.get());
			tabData.accept(BloatMonsterOresModItems.XPETERITE.get());
			tabData.accept(BloatMonsterOresModItems.ENDYSTER_INGOT.get());
			tabData.accept(BloatMonsterOresModItems.CHARGED_GUN_POWDER.get());
			tabData.accept(BloatMonsterOresModItems.FRESH_FLESH.get());
			tabData.accept(BloatMonsterOresModItems.BLAZED_COAL.get());
			tabData.accept(BloatMonsterOresModItems.ENDER_COAL.get());
			tabData.accept(BloatMonsterOresModItems.PHANTOM_COAL.get());
			tabData.accept(BloatMonsterOresModItems.PHANTOM_POWDER.get());

		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {

			tabData.accept(BloatMonsterOresModBlocks.BLAZE_POWDER_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.ENDER_PEARL_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.SLIME_BALL_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.GHAST_TEAR_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.FOSSIL_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.ROTTEN_FLESH_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PHANTOM_MEMBRANE_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.GLOW_INK_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.GUNPOWDER_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.SHULKER_SHELL_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.TOTEMITE_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.XPETERITE_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.SPIDER_EYE_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.ECHO_SHARD_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.PETRIFIED_WOOD_LEAVES.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.OREWOOD_COAL.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.OREWOOD_IRON.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.OREWOOD_GOLD.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.OREWOOD_REDSTONE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.OREWOOD_EMERALD.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.OREWOOD_LAPIS.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.DEEPSLATE_BLAZE_POWDER_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.DEEPSLATE_ENDER_PEARL_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.DEEPSLATE_MAGMA_CREAM_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.DEEPSLATE_GHAST_TEAR_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.DEEPSLATE_FRESH_FLESH_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.DEEPSLATE_PHANTOM_MEMBRANE_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.DEEPSLATE_GLOW_INK_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.DEEPSLATE_GUNPOWDER_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.DEEPSLATE_SHULKER_SHELL_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.DEEPSLATE_TOTEMITE_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.DEEPSLATE_XPETERITE_ORE.get().asItem());
			tabData.accept(BloatMonsterOresModBlocks.DEEPSLATE_SPIDER_EYE_ORE.get().asItem());

		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {

			tabData.accept(BloatMonsterOresModItems.FRESH_FLESH.get());
			tabData.accept(BloatMonsterOresModItems.HAMTASM.get());
			tabData.accept(BloatMonsterOresModItems.COOKED_HAMTASM.get());

		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {

			tabData.accept(BloatMonsterOresModItems.CHARGED_EXPLOSIVE_PICKAXE.get());
			tabData.accept(BloatMonsterOresModItems.ENDYSTER_PICKAXE.get());
			tabData.accept(BloatMonsterOresModItems.BLAZE_BONE.get());
			tabData.accept(BloatMonsterOresModItems.ENDS_SCYTHE.get());
			tabData.accept(BloatMonsterOresModItems.GILDED_HAMMER.get());
			tabData.accept(BloatMonsterOresModItems.ECTON_SCYTHE.get());
			tabData.accept(BloatMonsterOresModItems.SOULFLAME_HAMMER.get());
			tabData.accept(BloatMonsterOresModItems.ENDER_BONE.get());
			tabData.accept(BloatMonsterOresModItems.SOUL_BLAZE_BONE.get());

		}
	}
}

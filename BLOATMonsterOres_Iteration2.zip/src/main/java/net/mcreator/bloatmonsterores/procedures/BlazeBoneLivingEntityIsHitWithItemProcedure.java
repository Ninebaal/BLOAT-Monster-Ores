package net.mcreator.bloatmonsterores.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

public class BlazeBoneLivingEntityIsHitWithItemProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		entity.setSecondsOnFire(5);
		world.setBlock(BlockPos.containing(x + 0.5, y + 0.5, z + 0.5), Blocks.SOUL_FIRE.defaultBlockState(), 3);
	}
}


package net.mcreator.bloatmonsterores.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.SoundType;

public class TotemiteBrickWallsBlock extends WallBlock {
	public TotemiteBrickWallsBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.METAL).strength(1.5f, 6f).forceSolidOn());
	}
}

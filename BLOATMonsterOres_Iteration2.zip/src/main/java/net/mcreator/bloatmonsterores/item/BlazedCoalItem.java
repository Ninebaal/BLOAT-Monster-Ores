
package net.mcreator.bloatmonsterores.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class BlazedCoalItem extends Item {
	public BlazedCoalItem() {
		super(new Item.Properties().stacksTo(64).fireResistant().rarity(Rarity.COMMON));
	}
}

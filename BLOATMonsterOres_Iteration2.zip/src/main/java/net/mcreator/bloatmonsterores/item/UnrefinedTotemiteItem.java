
package net.mcreator.bloatmonsterores.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class UnrefinedTotemiteItem extends Item {
	public UnrefinedTotemiteItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON));
	}
}

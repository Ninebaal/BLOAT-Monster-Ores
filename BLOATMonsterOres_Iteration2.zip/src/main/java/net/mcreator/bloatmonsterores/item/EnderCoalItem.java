
package net.mcreator.bloatmonsterores.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class EnderCoalItem extends Item {
	public EnderCoalItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}


package net.mcreator.bloatmonsterores.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class EndysterIngotItem extends Item {
	public EndysterIngotItem() {
		super(new Item.Properties().stacksTo(64).fireResistant().rarity(Rarity.RARE));
	}
}
